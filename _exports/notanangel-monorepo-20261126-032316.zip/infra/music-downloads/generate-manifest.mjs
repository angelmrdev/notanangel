import {objectKey} from '../../apps/web/lib/music/downloads.mjs';
import {loadMusicCatalog,publishedMusic} from '../../apps/web/lib/music/catalog.mjs';
import {fileURLToPath} from 'node:url';
import {writeFileSync} from 'node:fs';
const root=fileURLToPath(new URL('../../apps/web/content/music/',import.meta.url));
const entries=publishedMusic(loadMusicCatalog(root)).flatMap(r=>r.downloads.filter(d=>d.enabled && d.rights==='authorized').map(d=>({releaseId:r.id,id:d.id,format:d.format,bytes:d.bytes,key:objectKey(r.category,r.slug,d.id,d.format),filename:`${r.slug}-${d.id}.${d.format}`})));
writeFileSync(new URL('./manifest.json',import.meta.url),JSON.stringify(entries,null,2)+'\n');
console.log(`Download manifest: ${entries.length} files`);
