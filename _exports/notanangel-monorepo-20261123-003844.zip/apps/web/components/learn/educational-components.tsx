import type { ReactNode } from 'react';
import Image from 'next/image';
import s from './educational-components.module.css';

type BlockProps = { title?: string; children: ReactNode };
export function KeyConcept({ title = 'Key concept', children }: BlockProps) {
 return <aside className={`${s.block} ${s.concept}`} aria-label={title}><strong>{title}</strong><div>{children}</div></aside>;
}
export function PracticeExercise({ title = 'Practice', children }: BlockProps) {
 return <section className={`${s.block} ${s.practice}`} aria-label={title}><strong>{title}</strong><div>{children}</div></section>;
}
export function DJTip({ title = 'DJ tip', children }: BlockProps) {
 return <aside className={`${s.block} ${s.tip}`} aria-label={title}><strong>{title}</strong><div>{children}</div></aside>;
}
export function LessonChecklist({ title = 'Before you move on', children }: BlockProps) {
 return <section className={`${s.block} ${s.checklist}`} aria-label={title}><strong>{title}</strong><div>{children}</div></section>;
}
export function LearnFigure({ src, alt, caption, width = 1200, height = 750 }: {
 src: string; alt: string; caption?: string; width?: number; height?: number;
}) {
 if (!src.startsWith('/') || src.startsWith('//')) throw new Error('LearnFigure src must be a local public asset path');
 if (!alt.trim()) throw new Error('LearnFigure requires meaningful alt text');
 return <figure className={s.figure}><Image src={src} alt={alt} width={width} height={height} style={{ width: '100%', height: 'auto' }} />{caption && <figcaption>{caption}</figcaption>}</figure>;
}



/** M05-E2: lightweight educational diagrams; no client JS or external assets. */
export function PhraseGrid({
  bars = 32, groupSize = 8, title = 'Counting musical bars',
}: { bars?: number; groupSize?: number; title?: string }) {
  if (!Number.isInteger(bars) || !Number.isInteger(groupSize) || bars < 1 || bars > 64 || groupSize < 1 || groupSize > 16) {
    throw new Error('PhraseGrid expects 1–64 bars and a group size of 1–16');
  }
  const groups = Array.from({ length: Math.ceil(bars / groupSize) }, (_, index) => {
    const start = index * groupSize + 1;
    return Array.from({ length: Math.min(groupSize, bars - index * groupSize) }, (__, offset) => start + offset);
  });
  return (
    <figure className={s.diagram}>
      <figcaption className={s.diagramHeading}>{title}</figcaption>
      <div className={s.phraseGroups} role="img" aria-label={`${bars} bars in groups of ${groupSize}; each group's first bar is highlighted`}>
        {groups.map((group, index) => (
          <div className={s.phraseGroup} key={index}>
            <span className={s.groupLabel}>Group {index + 1}</span>
            <div className={s.phraseBars}>
              {group.map((bar, offset) => <span key={bar} className={offset === 0 ? s.firstBar : s.phraseBar}>{bar}</span>)}
            </div>
            <span className={s.groupCaption}>{group.length} {group.length === 1 ? 'bar' : 'bars'}</span>
          </div>
        ))}
      </div>
      <p className={s.diagramFootnote}>Grouping is a counting aid, not a rule that every song changes section at these boundaries.</p>
    </figure>
  );
}

export function SignalChain({ title = 'The basic DJ audio path' }: { title?: string }) {
  return (
    <figure className={s.diagram}>
      <figcaption className={s.diagramHeading}>{title}</figcaption>
      <div className={s.signalDiagram} role="img" aria-label="Computer or music player sends playback to a controller or mixer, which routes the master signal to powered speakers and a separate cue signal to headphones.">
        <div className={s.signalNode}><small>01 · SOURCE</small><strong>Computer / player</strong><span>Audio playback</span></div>
        <span className={s.signalArrow} aria-hidden="true">→</span>
        <div className={s.signalNode}><small>02 · MIX</small><strong>Controller / mixer</strong><span>Channels and routing</span></div>
        <span className={s.signalArrow} aria-hidden="true">→</span>
        <div className={s.signalDestinations}>
          <div className={s.signalOutput}><small>MASTER</small><strong>Powered speakers / PA</strong></div>
          <div className={s.signalOutput}><small>CUE / PHONES</small><strong>DJ headphones</strong></div>
        </div>
      </div>
      <p className={s.diagramFootnote}>Conceptual diagram. Hardware connections and routing depend on the devices; the private cue path is separate from the program mix.</p>
    </figure>
  );
}

export function LessonCheckpoint({
  title = 'Quick self-check', items,
}: { title?: string; items: string[] }) {
  return (
    <section className={s.checkpoint} aria-label={title}>
      <strong className={s.checkpointTitle}>{title}</strong>
      <ul>{items.map((item, index) => <li key={`${index}-${item}`}>{item}</li>)}</ul>
    </section>
  );
}

export const learnMdxComponents = { KeyConcept, PracticeExercise, DJTip, LessonChecklist, LearnFigure, PhraseGrid, SignalChain, LessonCheckpoint };
