import data from '@/config/blog-products.json';
import s from './product-components.module.css';

type ProductId = keyof typeof data.products;
function getProduct(id: string) {
  const product = data.products[id as ProductId];
  if (!product) throw new Error(`Unknown product identifier: ${id}`);
  return product;
}
function Price({min,max}:{min:number,max:number}) {return <span>{min}–{max} €</span>}
export function AffiliateDisclosure(){return <aside className={s.disclosure}><strong>Transparencia editorial</strong><p>Esta guía puede contener enlaces de afiliado. Si compras a través de ellos, Not an Angel puede recibir una comisión sin coste adicional para ti. Los rangos de precio son orientativos, no ofertas en tiempo real.</p></aside>}
export function ProductCard({productId,variant='standard'}:{productId:string,variant?:'standard'|'featured'}) {
 const p=getProduct(productId);
 return <section aria-label={`Ficha de ${p.name}`} className={`${s.product} ${variant==='featured'?s.featured:''}`}>
  <div className={s.image} aria-label={`Espacio reservado para fotografía de ${p.name}`}><span>NOT AN ANGEL / DJ GEAR</span><strong>{p.name}</strong><small>IMAGEN EN PREPARACIÓN</small></div>
  <div className={s.info}><span className={s.kicker}>{p.bestFor}</span><h3>{p.brand} {p.name}</h3><p>{p.quickSpecs}</p><p className={s.software}>Software: {p.software}</p><div className={s.bottom}><div><span className={s.priceLabel}>Precio orientativo</span><strong className={s.price}><Price min={p.priceMinEUR} max={p.priceMaxEUR}/></strong></div><a href={p.affiliateUrlES} target="_blank" rel="sponsored nofollow noopener noreferrer" aria-label={`Consultar ${p.name} en Amazon España`}>Consultar en Amazon.es ↗</a></div><small className={s.fine}>Consulta el precio y disponibilidad actuales en Amazon.es. Enlace de afiliado.</small></div>
 </section>;
}
export function ProductComparison({productIds}:{productIds:string[]}) {
 const products=productIds.map(getProduct);
 return <div className={s.scroll}><table className={s.comparison}><caption>Comparativa orientativa de controladoras para principiantes</caption><thead><tr><th scope="col">Modelo</th><th scope="col">Recomendación</th><th scope="col">Software</th><th scope="col">Precio aprox.</th><th scope="col">Tienda</th></tr></thead><tbody>{products.map(p=><tr key={p.id}><th scope="row">{p.brand} {p.name}</th><td>{p.bestFor}</td><td>{p.software}</td><td><Price min={p.priceMinEUR} max={p.priceMaxEUR}/></td><td><a href={p.affiliateUrlES} target="_blank" rel="sponsored nofollow noopener noreferrer">Amazon.es ↗</a></td></tr>)}</tbody></table></div>
}
export function PriceNotice(){return <p className={s.notice}>Precios orientativos para producto nuevo en España, consultados en noviembre de 2026. No son ofertas garantizadas ni precios necesariamente vigentes. Comprueba precio, vendedor, versión y disponibilidad antes de comprar.</p>}
export function VisualPlaceholder({title,description}:{title:string,description?:string}){return <figure className={s.visual}><span>NOT AN ANGEL / VISUAL GUIDE</span><strong>{title}</strong>{description&&<p>{description}</p>}<figcaption>Diagrama editorial en preparación. Este bloque será sustituido por el recurso definitivo.</figcaption></figure>}
