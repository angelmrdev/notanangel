import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { LearnLessonPage } from '@/components/learn/learn-pages';
import { getPublishedLearnModules, learnLessonUrl } from '@/lib/learn/repository';
const locale='en' as const;
export const dynamicParams=false;
const EMPTY='__empty__';
export function generateStaticParams(){const params=getPublishedLearnModules(locale).flatMap(entry=>entry.lessons.map(lesson=>({module:entry.module.slugs[locale],lesson:lesson.slug})));return params.length?params:[{module:EMPTY,lesson:EMPTY}];}
export async function generateMetadata({params}:{params:Promise<{module:string,lesson:string}>}):Promise<Metadata>{const {module,lesson}=await params;const entry=getPublishedLearnModules(locale).find(x=>x.module.slugs[locale]===module);const item=entry?.lessons.find(x=>x.slug===lesson);if(!entry||!item)return {title:'Not found',robots:{index:false}};const otherLocale='es' as const;const other=getPublishedLearnModules(otherLocale).find(x=>x.module.id===entry.module.id)?.lessons.find(x=>x.id===item.id);return {title:item.title,description:item.description,alternates:{canonical:learnLessonUrl(entry.module,item),languages:other?{[locale]:learnLessonUrl(entry.module,item),[otherLocale]:learnLessonUrl(entry.module,other)}:undefined},robots:{index:true}};}
export default async function Page({params}:{params:Promise<{module:string,lesson:string}>}){const {module,lesson}=await params;const entry=getPublishedLearnModules(locale).find(x=>x.module.slugs[locale]===module);const item=entry?.lessons.find(x=>x.slug===lesson);if(!entry||!item){if(module===EMPTY&&lesson===EMPTY)return <main aria-label="Empty learn route"/>;notFound();}return <LearnLessonPage entry={entry} lesson={item}/>;}
