import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { LearnModulePage } from '@/components/learn/learn-pages';
import { getPublishedLearnModules, learnModuleUrl } from '@/lib/learn/repository';
const locale='en' as const;
export const dynamicParams=false;
const EMPTY='__empty__';
export function generateStaticParams(){const slugs=getPublishedLearnModules(locale).map(x=>x.module.slugs[locale]);return (slugs.length?slugs:[EMPTY]).map(module=>({module}));}
export async function generateMetadata({params}:{params:Promise<{module:string}>}):Promise<Metadata>{const {module}=await params;const entry=getPublishedLearnModules(locale).find(x=>x.module.slugs[locale]===module);if(!entry)return {title:'Not found',robots:{index:false}};return {title:entry.page.title,description:entry.page.description,alternates:{canonical:learnModuleUrl(entry.module,locale),languages:{en:learnModuleUrl(entry.module,'en'),es:learnModuleUrl(entry.module,'es')}},robots:{index:true}};}
export default async function Page({params}:{params:Promise<{module:string}>}){const {module}=await params;const entry=getPublishedLearnModules(locale).find(x=>x.module.slugs[locale]===module);if(!entry&&module===EMPTY)return <main aria-label="Empty learn route"/>;if(!entry)notFound();return <LearnModulePage entry={entry}/>;}
