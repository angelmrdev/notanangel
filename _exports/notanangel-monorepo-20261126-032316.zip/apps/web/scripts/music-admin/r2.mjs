import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {mkdtemp,stat,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {objectKey} from '../../lib/music/downloads.mjs';
const exec=promisify(execFile);
const config=fileURLToPath(new URL('../../../../infra/music-downloads/wrangler.toml',import.meta.url));
export async function checkR2(input,run=exec){
 const key=objectKey(input.category,input.slug,input.id,input.format);
 const pnpm=process.env.npm_execpath;
 if(!pnpm)throw Error('Start Music Admin using pnpm exec as documented');
 const dir=await mkdtemp(join(tmpdir(),'naa-r2-'));const file=join(dir,'audio');
 try{
  await run(process.execPath,[pnpm,'dlx','wrangler@4.168.0','r2','object','get',`notanangel/${key}`,'--remote','--file',file,'--config',config],{timeout:180000,maxBuffer:1024*1024,windowsHide:true});
  const {size}=await stat(file);if(!size)throw Error('Empty object');return {key,bytes:size};
 }catch{throw Error('R2 check failed: verify object, Wrangler login and connection');}finally{await rm(dir,{recursive:true,force:true});}
}
