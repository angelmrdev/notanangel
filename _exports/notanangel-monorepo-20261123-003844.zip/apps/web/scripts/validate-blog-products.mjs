import { readFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
const root = process.cwd();
const catalog = JSON.parse(readFileSync(resolve(root,'config/blog-products.json'),'utf8'));
const ids = Object.keys(catalog.products);
const checked = new Set();
for (const [id, p] of Object.entries(catalog.products)) {
 if (id !== p.id || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(id)) throw new Error(`Invalid product id: ${id}`);
 if (!(Number.isFinite(p.priceMinEUR) && Number.isFinite(p.priceMaxEUR) && p.priceMinEUR > 0 && p.priceMaxEUR >= p.priceMinEUR)) throw new Error(`Invalid price range: ${id}`);
 if (!/^https:\/\/(link\.amazon|www\.amazon\.es|amazon\.es)\//.test(p.affiliateUrlES)) throw new Error(`Invalid affiliate URL format: ${id}`);
}
for (const locale of ['es','en']) {
 const dir=resolve(root,'content/blog',locale);
 let names=[];try {names=readdirSync(dir).filter(x=>x.endsWith('.mdx'));}catch {continue;}
 for (const name of names) {
  const source=readFileSync(resolve(dir,name),'utf8');
  const matches=[...source.matchAll(/productId="([^"]+)"/g),...source.matchAll(/'([a-z0-9-]+)'/g).filter(m=>ids.includes(m[1]))];
  for (const m of matches) if (!catalog.products[m[1]]) throw new Error(`Unknown product ${m[1]} in ${name}`);else checked.add(m[1]);
 }
}
console.log(`Product catalog validated: ${ids.length} entries; ${checked.size} referenced IDs.`);
