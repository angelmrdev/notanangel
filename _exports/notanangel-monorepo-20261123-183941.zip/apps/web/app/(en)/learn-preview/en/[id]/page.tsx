import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { compileMDX } from 'next-mdx-remote/rsc';
import remarkGfm from 'remark-gfm';
import { mdxComponents } from '@/components/blog/mdx-components';
import { learnMdxComponents } from '@/components/learn/educational-components';
import { getLearnManifest, readLearnLesson } from '@/lib/learn/repository';
import type { LearnLocale } from '@/lib/learn/types';
import s from '@/components/learn/learn.module.css';

/** M05-E1: local development ONLY. No public draft routes, no publication state changes. */
export const dynamicParams = false;
export function generateStaticParams() {
  return getLearnManifest().flatMap((entry) => entry.lessonIds.map((id) => ({ id })));
}
export const metadata: Metadata = { title: 'DJ Learn — Draft preview', robots: { index: false, follow: false, nocache: true } };

export default async function PreviewLesson({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  // Never expose draft content in production, preview deployments or other NODE_ENVs.
  if (process.env.NODE_ENV !== 'development') notFound();
  const { id } = await params;
  const locale: LearnLocale = 'en';
  const learnModule = getLearnManifest().find((m) => m.lessonIds.includes(id));
  if (!learnModule) notFound();
  const lesson = readLearnLesson(id, locale);
  if (!lesson || lesson.moduleId !== learnModule.id) notFound();

  const { content } = await compileMDX({
    source: lesson.body,
    components: { ...mdxComponents, ...learnMdxComponents },
    options: { mdxOptions: { remarkPlugins: [remarkGfm] } },
  });
  const siblings = learnModule.lessonIds.map((lessonId) => ({ id: lessonId, lesson: readLearnLesson(lessonId, locale) }));

  return (
    <main className={s.wrap}>
      <p className={s.eyebrow}>Local development preview · {locale.toUpperCase()} · {lesson.id}</p>
      <h1 className={s.pageTitle}>{lesson.title}</h1>
      <p className={s.intro}>{lesson.description}</p>
      <div className={s.moduleLayout}>
        <article>
          <div className={s.reading}>{content}</div>
        </article>
        <aside className={s.side}>
          <h2>{locale === 'en' ? 'Draft lessons' : 'Lecciones en borrador'}</h2>
          <ol>
            {siblings.filter((entry) => entry.lesson).map((entry) => (
              <li key={entry.id}>
                <Link
                  href={`/learn-preview/en/${entry.id}/`}
                  aria-current={entry.id === id ? 'page' : undefined}
                >
                  {entry.lesson!.title}
                </Link>
              </li>
            ))}
          </ol>
        </aside>
      </div>
    </main>
  );
}
